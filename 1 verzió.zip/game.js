
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const restartBtn = document.getElementById('restartBtn');

const ASSET_PATH = 'assets/';
const images = {};
const imageNames = [
  'player_car.png','car_blue.png','car_pink.png','car_yellow.png',
  'pen_icon.png','notebook_icon.png','sticker_icon.png','marker_icon.png'
];

const keys = {};
window.addEventListener('keydown', (e) => {
  const key = e.key.toLowerCase();
  keys[key] = true;
  if (['w','a','d','arrowup','arrowleft','arrowright',' '].includes(key)) e.preventDefault();
});
window.addEventListener('keyup', (e) => {
  keys[e.key.toLowerCase()] = false;
});
restartBtn.addEventListener('click', () => resetGame());

const GAME = {
  width: 520,
  height: 760,
  roadX: 108,
  roadW: 304,
  laneCenters: [158, 260, 362],
  roadSpeed: 6.2,
};

let state;

function loadAssets(callback){
  let loaded = 0;
  imageNames.forEach(name => {
    const img = new Image();
    img.onload = () => {
      loaded++;
      if (loaded === imageNames.length) callback();
    };
    img.src = ASSET_PATH + name;
    images[name] = img;
  });
}

function resetGame(){
  state = {
    running: true,
    win: false,
    gameOver: false,
    score: 0,
    lives: 3,
    spawnTimer: 0,
    itemTimer: 0,
    flashTimer: 0,
    message: 'Gyűjts 18 tárgyat a kuponhoz!',
    roadOffset: 0,
    milestone: 0,
    player: {
      x: 260,
      y: 612,
      w: 74,
      h: 124,
      speedX: 5.8,
      speedY: 4.8
    },
    cars: [],
    items: [],
    particles: []
  };
}

function spawnCar(){
  const types = ['car_blue.png', 'car_pink.png', 'car_yellow.png'];
  const type = types[Math.floor(Math.random()*types.length)];
  const lane = GAME.laneCenters[Math.floor(Math.random()*GAME.laneCenters.length)];
  const w = 70 + Math.random()*8;
  const h = 118 + Math.random()*10;
  state.cars.push({
    x: lane,
    y: -160,
    w,
    h,
    img: type,
    speed: GAME.roadSpeed + 0.5 + Math.random()*1.6
  });
}

function spawnItem(){
  const types = ['pen_icon.png', 'notebook_icon.png', 'sticker_icon.png', 'marker_icon.png'];
  const lane = GAME.laneCenters[Math.floor(Math.random()*GAME.laneCenters.length)];
  state.items.push({
    x: lane,
    y: -60,
    size: 42,
    img: types[Math.floor(Math.random()*types.length)],
    speed: GAME.roadSpeed + 0.2
  });
}

function clamp(v, min, max){ return Math.max(min, Math.min(max, v)); }

function overlaps(a,b){
  return (
    a.x - a.w/2 < b.x + b.w/2 &&
    a.x + a.w/2 > b.x - b.w/2 &&
    a.y - a.h/2 < b.y + b.h/2 &&
    a.y + a.h/2 > b.y - b.h/2
  );
}

function loseLife(){
  if (state.flashTimer > 0) return;
  state.lives -= 1;
  state.flashTimer = 60;
  state.message = state.lives > 0 ? 'Ütközés! -1 élet' : 'Elfogytak az életek';
  if (state.lives <= 0){
    state.running = false;
    state.gameOver = true;
  }
}

function update(){
  if (!state.running) return;

  const p = state.player;
  if (keys['a'] || keys['arrowleft']) p.x -= p.speedX;
  if (keys['d'] || keys['arrowright']) p.x += p.speedX;
  if (keys['w'] || keys['arrowup']) p.y -= p.speedY;
  else p.y += 1.2; // gentle drift back down to keep the road feeling alive

  p.x = clamp(p.x, GAME.roadX + 32, GAME.roadX + GAME.roadW - 32);
  p.y = clamp(p.y, 370, 640);

  state.roadOffset = (state.roadOffset + GAME.roadSpeed) % 120;
  if (state.flashTimer > 0) state.flashTimer--;

  state.spawnTimer++;
  state.itemTimer++;
  if (state.spawnTimer > 42){
    spawnCar();
    state.spawnTimer = 0;
  }
  if (state.itemTimer > 64){
    spawnItem();
    state.itemTimer = 0;
  }

  state.cars.forEach(car => car.y += car.speed);
  state.items.forEach(item => item.y += item.speed);

  state.cars = state.cars.filter(car => car.y < GAME.height + 180);
  state.items = state.items.filter(item => item.y < GAME.height + 100);

  const playerBox = {x:p.x, y:p.y, w:p.w*0.74, h:p.h*0.78};

  for (const car of state.cars){
    const carBox = {x:car.x, y:car.y, w:car.w*0.72, h:car.h*0.78};
    if (overlaps(playerBox, carBox)){
      loseLife();
      car.y = GAME.height + 200;
      break;
    }
  }

  for (const item of state.items){
    const itemBox = {x:item.x, y:item.y, w:item.size, h:item.size};
    if (overlaps({x:p.x, y:p.y, w:p.w*0.6, h:p.h*0.6}, itemBox)){
      state.score += 1;
      item.y = GAME.height + 120;
      state.message = 'Tárgy gyűjtve!';
      if (state.score % 10 === 0 && state.score !== state.milestone){
        state.milestone = state.score;
        state.message = 'Mérföldkő elérve!';
      }
      if (state.score >= 18){
        state.running = false;
        state.win = true;
        state.message = 'Kupon feloldva!';
      }
    }
  }
}

function drawGrass(){
  ctx.fillStyle = '#a9e4bf';
  ctx.fillRect(0,0,GAME.width,GAME.height);

  // dotted lawn pattern
  ctx.fillStyle = 'rgba(65,170,95,.28)';
  for (let x=18; x<GAME.width; x+=40){
    for (let y=14; y<GAME.height; y+=54){
      if (x < GAME.roadX-10 || x > GAME.roadX+GAME.roadW+10){
        ctx.beginPath();
        ctx.arc(x, y, 6, 0, Math.PI*2);
        ctx.fill();
      }
    }
  }

  // flowers
  const flowerSpots = [35, 72, 108, 146, 181, 220, 257, 295, 331, 368, 407, 445, 485, 522, 560, 598, 636, 675, 712];
  flowerSpots.forEach((y, idx) => {
    drawFlower(44, (y + state.roadOffset*0.8 + idx*7) % (GAME.height+40) - 20, idx % 2 === 0 ? '#ff77ab' : '#ffffff');
    drawFlower(GAME.width-46, (y + state.roadOffset*1.1 + idx*11) % (GAME.height+40) - 20, idx % 2 === 0 ? '#ffffff' : '#ff77ab');
  });
}

function drawFlower(x, y, petalColor){
  const center = petalColor === '#ffffff' ? '#ffc96a' : '#ffe07a';
  if (y < -20 || y > GAME.height+20) return;
  for (let i=0;i<5;i++){
    const ang = (Math.PI*2/5)*i;
    ctx.fillStyle = petalColor;
    ctx.beginPath();
    ctx.arc(x + Math.cos(ang)*7, y + Math.sin(ang)*7, 5, 0, Math.PI*2);
    ctx.fill();
  }
  ctx.fillStyle = center;
  ctx.beginPath();
  ctx.arc(x, y, 4, 0, Math.PI*2);
  ctx.fill();
  ctx.fillStyle = '#2a8b56';
  ctx.fillRect(x-1, y+7, 2, 8);
}

function drawRoad(){
  ctx.fillStyle = '#55527c';
  ctx.fillRect(GAME.roadX, 0, GAME.roadW, GAME.height);

  ctx.fillStyle = '#f2c94c';
  ctx.fillRect(GAME.roadX-3, 0, 6, GAME.height);
  ctx.fillRect(GAME.roadX+GAME.roadW-3, 0, 6, GAME.height);

  ctx.strokeStyle = 'rgba(255,255,255,.55)';
  ctx.lineWidth = 4;
  [GAME.roadX + GAME.roadW/3, GAME.roadX + GAME.roadW*2/3].forEach(x => {
    for (let y=-120; y<GAME.height+120; y+=120){
      const yy = y + state.roadOffset;
      ctx.beginPath();
      ctx.moveTo(x, yy);
      ctx.lineTo(x, yy+64);
      ctx.stroke();
    }
  });
}

function drawHUD(){
  ctx.fillStyle = 'rgba(18, 22, 42, .78)';
  ctx.roundRect(16, 14, 182, 86, 18);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.font = '700 18px Arial';
  ctx.fillText('Pont: ' + state.score, 28, 45);
  ctx.fillText('Életek: ' + state.lives, 28, 72);

  ctx.fillStyle = 'rgba(18,22,42,.78)';
  ctx.roundRect(206, 14, 298, 52, 18);
  ctx.fill();
  ctx.fillStyle = '#ffffff';
  ctx.font = '600 16px Arial';
  ctx.fillText(state.message, 220, 46);
}

function drawOverlay(title, subtitle){
  ctx.fillStyle = 'rgba(14, 18, 33, .62)';
  ctx.fillRect(0,0,GAME.width,GAME.height);
  ctx.fillStyle = '#ffffff';
  ctx.roundRect(70, 220, GAME.width-140, 240, 28);
  ctx.fill();
  ctx.fillStyle = '#1f2447';
  ctx.font = '700 34px Arial';
  ctx.textAlign = 'center';
  ctx.fillText(title, GAME.width/2, 285);
  ctx.font = '20px Arial';
  wrapText(subtitle, GAME.width/2, 332, 320, 28);
  ctx.font = '700 18px Arial';
  ctx.fillStyle = '#4a57b2';
  ctx.fillText('Újraindítás: gomb a jobb felső sarokban', GAME.width/2, 412);
  ctx.textAlign = 'left';
}

function wrapText(text, centerX, y, maxWidth, lineHeight){
  const words = text.split(' ');
  let line = '';
  for (let i=0;i<words.length;i++){
    const test = line + words[i] + ' ';
    if (ctx.measureText(test).width > maxWidth && i > 0){
      ctx.fillText(line.trim(), centerX, y);
      y += lineHeight;
      line = words[i] + ' ';
    } else {
      line = test;
    }
  }
  ctx.fillText(line.trim(), centerX, y);
}

function drawGame(){
  drawGrass();
  drawRoad();

  // draw collectibles
  state.items.forEach(item => {
    const img = images[item.img];
    if (img) ctx.drawImage(img, item.x-item.size/2, item.y-item.size/2, item.size, item.size);
  });

  // obstacle cars
  state.cars.forEach(car => {
    const img = images[car.img];
    if (img) ctx.drawImage(img, car.x - car.w/2, car.y - car.h/2, car.w, car.h);
  });

  // player car
  const p = state.player;
  if (state.flashTimer > 0 && Math.floor(state.flashTimer / 4) % 2 === 0){
    ctx.globalAlpha = 0.55;
  }
  ctx.drawImage(images['player_car.png'], p.x - p.w/2, p.y - p.h/2, p.w, p.h);
  ctx.globalAlpha = 1;

  // road bottom shadow
  ctx.fillStyle = 'rgba(255,255,255,.82)';
  ctx.fillRect(0, GAME.height-28, GAME.width, 28);

  drawHUD();

  if (state.gameOver){
    drawOverlay('Vége a játéknak', 'Elfogytak az életeid. Próbáld meg újra, és gyűjtsd össze a GoriPen tárgyakat!');
  }
  if (state.win){
    drawOverlay('Kupon feloldva!', 'Gratulálunk! Megszerezted a GORIPEN10 kuponkódot a webshophoz.');
  }
}

function loop(){
  update();
  drawGame();
  requestAnimationFrame(loop);
}

function start(){
  resetGame();
  loop();
}

CanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h, r) {
  this.beginPath();
  this.moveTo(x+r, y);
  this.arcTo(x+w, y, x+w, y+h, r);
  this.arcTo(x+w, y+h, x, y+h, r);
  this.arcTo(x, y+h, x, y, r);
  this.arcTo(x, y, x+w, y, r);
  this.closePath();
  return this;
};

loadAssets(start);
