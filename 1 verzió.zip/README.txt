GoriPen – hordozható, Lovable nélkül is megnyitható verzió

Tartalom:
- index.html
- style.css
- game.js
- assets mappa

Indítás:
1. Nyisd meg a mappát VS Code-ban vagy sima fájlkezelőből.
2. Nyisd meg az index.html fájlt böngészőben.
3. Ha van Live Servered, azzal is futtatható.

Irányítás:
- W: előre / fel
- A: balra
- D: jobbra

Megjegyzés:
A logóhoz a feltöltött GoriPen logó lett felhasználva.
A fő karakterhez a feltöltött menő gorilla lett felhasználva.
