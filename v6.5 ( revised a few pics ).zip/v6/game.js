
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const startBtn = document.getElementById('startGameBtn');

const CANVAS_W = 420;
const CANVAS_H = 620;
const ROAD_LEFT = 65;
const ROAD_RIGHT = CANVAS_W - 65;
const ROAD_W = ROAD_RIGHT - ROAD_LEFT;
const LANE_COUNT = 4;
const LANE_W = ROAD_W / LANE_COUNT;
const CAR_W = 38;
const CAR_H = 60;
const ITEM_SIZE = 26;
const OBS_SPEED_BASE = 2.2;
const ITEM_SPEED_BASE = 1.8;
const PLAYER_SPEED_X = 3.5;
const PLAYER_SPEED_Y = 2.8;
const PLAYER_ACCEL = 0.4;
const PLAYER_FRICTION = 0.88;
const SPAWN_INTERVAL = 65;
const ITEM_INTERVAL = 48;
const MILESTONE_ITEMS = [10, 25, 50];

const STATIONERY_ITEMS = ["🖊️", "📓", "⭐", "🖍️", "📎", "✏️", "📏"];
const CAR_COLORS = ["#e74c3c", "#3498db", "#e67e22", "#9b59b6", "#1abc9c", "#f39c12"];
const GRASS_COLOR = "#7ec850";
const ROAD_COLOR = "#4a4a4a";
const SHOULDER_COLOR = "#666";
const PLAYER_COLOR = "hsl(158, 55%, 42%)";
const PLAYER_ROOF = "hsl(158, 55%, 55%)";

let state = null;

function resetGame(){
  state = {
    mode: "menu",
    finalScore: 0,
    unlockedCoupon: null,
    playerX: CANVAS_W / 2 - CAR_W / 2,
    playerY: CANVAS_H - CAR_H - 40,
    velX: 0,
    velY: 0,
    lives: 3,
    score: 0,
    collected: 0,
    obstacles: [],
    items: [],
    keys: {},
    frame: 0,
    roadOffset: 0,
    milestone: 0,
    flashTimer: 0,
    invincible: 0,
    animationId: null
  };
}

function startGame(){
  resetGame();
  state.mode = "playing";
}

window.addEventListener("keydown", (e) => {
  if (!state) return;
  const key = e.key.toLowerCase();
  if (["w","a","s","d","arrowup","arrowdown","arrowleft","arrowright"].includes(key)) {
    e.preventDefault();
  }
  state.keys[key] = true;
});
window.addEventListener("keyup", (e) => {
  if (!state) return;
  state.keys[e.key.toLowerCase()] = false;
});

startBtn.addEventListener("click", () => {
  startGame();
});

function drawCar(x, y, color, isPlayer){
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = color;
  roundRect(-CAR_W/2, -CAR_H/2, CAR_W, CAR_H, 10);
  ctx.fill();

  ctx.fillStyle = isPlayer ? PLAYER_ROOF : "rgba(255,255,255,.65)";
  roundRect(-CAR_W/2 + 6, -CAR_H/2 + 8, CAR_W - 12, 20, 8);
  ctx.fill();

  ctx.fillStyle = isPlayer ? "#ffe2d1" : "rgba(255,255,255,.3)";
  roundRect(-CAR_W/2 + 8, -6, CAR_W - 16, 16, 8);
  ctx.fill();

  ctx.fillStyle = "#222";
  ctx.fillRect(-CAR_W/2 - 4, -CAR_H/2 + 10, 5, 13);
  ctx.fillRect(CAR_W/2 - 1, -CAR_H/2 + 10, 5, 13);
  ctx.fillRect(-CAR_W/2 - 4, CAR_H/2 - 24, 5, 13);
  ctx.fillRect(CAR_W/2 - 1, CAR_H/2 - 24, 5, 13);

  if (isPlayer) {
    ctx.font = "16px serif";
    ctx.fillText("🦍", -8, -10);
  }

  ctx.fillStyle = "#ffd8c4";
  roundRect(-CAR_W/2 + 6, CAR_H/2 - 10, 9, 5, 3);
  ctx.fill();
  roundRect(CAR_W/2 - 15, CAR_H/2 - 10, 9, 5, 3);
  ctx.fill();

  ctx.restore();
}

function roundRect(x, y, w, h, r){
  ctx.beginPath();
  ctx.moveTo(x+r, y);
  ctx.arcTo(x+w, y, x+w, y+h, r);
  ctx.arcTo(x+w, y+h, x, y+h, r);
  ctx.arcTo(x, y+h, x, y, r);
  ctx.arcTo(x, y, x+w, y, r);
  ctx.closePath();
}

function update(){
  if (!state || state.mode !== "playing") return;

  state.frame++;
  const speed = OBS_SPEED_BASE + state.score * 0.004;

  if (state.keys["a"] || state.keys["arrowleft"]) state.velX -= PLAYER_ACCEL;
  if (state.keys["d"] || state.keys["arrowright"]) state.velX += PLAYER_ACCEL;
  if (state.keys["w"] || state.keys["arrowup"]) state.velY -= PLAYER_ACCEL;
  if (state.keys["s"] || state.keys["arrowdown"]) state.velY += PLAYER_ACCEL * 0.5;

  state.velX *= PLAYER_FRICTION;
  state.velY *= PLAYER_FRICTION;

  state.velX = Math.max(-PLAYER_SPEED_X, Math.min(PLAYER_SPEED_X, state.velX));
  state.velY = Math.max(-PLAYER_SPEED_Y, Math.min(PLAYER_SPEED_Y, state.velY));

  state.playerX += state.velX;
  state.playerY += state.velY;

  state.playerX = Math.max(ROAD_LEFT + 6, Math.min(ROAD_RIGHT - CAR_W - 6, state.playerX));
  state.playerY = Math.max(70, Math.min(CANVAS_H - CAR_H - 12, state.playerY));

  state.roadOffset = (state.roadOffset + speed) % 40;
  if (state.invincible > 0) state.invincible--;
  if (state.flashTimer > 0) state.flashTimer--;

  if (state.frame % Math.max(28, SPAWN_INTERVAL - Math.floor(state.score / 4)) === 0) {
    const lane = Math.floor(Math.random() * LANE_COUNT);
    state.obstacles.push({
      x: ROAD_LEFT + lane * LANE_W + (LANE_W - CAR_W) / 2 + CAR_W / 2,
      y: -CAR_H - 10 + CAR_H/2,
      color: CAR_COLORS[Math.floor(Math.random() * CAR_COLORS.length)],
      w: CAR_W, h: CAR_H
    });
  }

  if (state.frame % ITEM_INTERVAL === 0) {
    state.items.push({
      x: ROAD_LEFT + 18 + Math.random() * (ROAD_W - 36),
      y: -ITEM_SIZE,
      emoji: STATIONERY_ITEMS[Math.floor(Math.random() * STATIONERY_ITEMS.length)]
    });
  }

  state.obstacles.forEach(o => o.y += speed);
  state.obstacles = state.obstacles.filter(o => o.y < CANVAS_H + 40);

  state.items.forEach(i => i.y += ITEM_SPEED_BASE + speed * 0.3);
  state.items = state.items.filter(i => i.y < CANVAS_H + 20);

  if (state.invincible <= 0) {
    for (const o of state.obstacles) {
      if (
        state.playerX < o.x + o.w/2 - 8 &&
        state.playerX + CAR_W > o.x - o.w/2 + 8 &&
        state.playerY < o.y + o.h/2 - 8 &&
        state.playerY + CAR_H > o.y - o.h/2 + 8
      ) {
        state.lives--;
        state.invincible = 90;
        state.flashTimer = 30;
        o.y = CANVAS_H + 100;
        if (state.lives <= 0) {
          state.finalScore = state.score;
          state.mode = "over";
          return;
        }
      }
    }
  }

  for (let i = state.items.length - 1; i >= 0; i--) {
    const it = state.items[i];
    const cx = state.playerX + CAR_W / 2;
    const cy = state.playerY + CAR_H / 2;
    if (Math.abs(cx - it.x) < 26 && Math.abs(cy - it.y) < 26) {
      state.items.splice(i, 1);
      state.score += 1;
      state.collected += 1;
      for (let m = MILESTONE_ITEMS.length - 1; m >= 0; m--) {
        if (state.collected >= MILESTONE_ITEMS[m] && state.milestone <= m) {
          state.milestone = m + 1;
          state.unlockedCoupon = ["GORI5", "GORI10", "GORI20"][m];
          state.flashTimer = 60;
        }
      }
    }
  }
}

function drawBackground(){
  ctx.fillStyle = GRASS_COLOR;
  ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

  for (let fy = 0; fy < CANVAS_H; fy += 45) {
    for (const fx of [12, 38, CANVAS_W - 38, CANVAS_W - 12]) {
      const offset = ((fy + state.roadOffset * 2) % 90) - 5;
      ctx.font = "9px serif";
      ctx.fillText("🌼", fx + (fy % 18) - 4, fy + offset);
    }
  }

  ctx.fillStyle = SHOULDER_COLOR;
  ctx.fillRect(ROAD_LEFT - 4, 0, ROAD_W + 8, CANVAS_H);

  ctx.fillStyle = ROAD_COLOR;
  ctx.fillRect(ROAD_LEFT, 0, ROAD_W, CANVAS_H);

  ctx.fillStyle = "#eee";
  ctx.fillRect(ROAD_LEFT, 0, 3, CANVAS_H);
  ctx.fillRect(ROAD_RIGHT - 3, 0, 3, CANVAS_H);

  ctx.strokeStyle = "#aaa";
  ctx.lineWidth = 2;
  ctx.setLineDash([18, 18]);
  for (let l = 1; l < LANE_COUNT; l++) {
    const lx = ROAD_LEFT + l * LANE_W;
    ctx.beginPath();
    for (let dy = -state.roadOffset; dy < CANVAS_H + 40; dy += 36) {
      ctx.moveTo(lx, dy);
      ctx.lineTo(lx, dy + 18);
    }
    ctx.stroke();
  }
  ctx.setLineDash([]);
}

function drawHUD(){
  ctx.fillStyle = "rgba(255,255,255,.92)";
  roundRect(10, 10, 190, 70, 14);
  ctx.fill();
  ctx.fillStyle = "#1f2b25";
  ctx.font = "bold 16px Arial";
  ctx.fillText("Pont: " + state.score, 22, 35);
  ctx.fillText("Életek: " + state.lives, 22, 58);

  if (state.unlockedCoupon) {
    ctx.fillStyle = "rgba(255,255,255,.92)";
    roundRect(220, 10, 190, 70, 14);
    ctx.fill();
    ctx.fillStyle = "#2f9a69";
    ctx.fillText("Kupon: " + state.unlockedCoupon, 232, 47);
  }
}

function drawMenu(){
  drawBackground();
  ctx.fillStyle = "rgba(255,255,255,.95)";
  roundRect(50, 190, 320, 170, 20);
  ctx.fill();
  ctx.fillStyle = "#1f2b25";
  ctx.font = "bold 30px Arial";
  ctx.fillText("GoriPen Road Rush", 78, 238);
  ctx.font = "16px Arial";
  ctx.fillText("Nyomd meg a Start Game gombot!", 92, 276);
  ctx.fillText("W / A / D - irányítás", 124, 305);
}

function drawEnd(title, sub){
  drawBackground();
  ctx.fillStyle = "rgba(255,255,255,.95)";
  roundRect(50, 190, 320, 190, 20);
  ctx.fill();
  ctx.fillStyle = "#1f2b25";
  ctx.font = "bold 28px Arial";
  ctx.fillText(title, 115, 236);
  ctx.font = "16px Arial";
  ctx.fillText(sub, 86, 276);
  ctx.fillText("Pontszám: " + state.finalScore, 138, 304);
  if (state.unlockedCoupon) {
    ctx.fillText("Utolsó kupon: " + state.unlockedCoupon, 110, 332);
  }
}

function render(){
  if (!state) return;

  if (state.mode === "menu") {
    drawMenu();
    return;
  }

  if (state.mode === "over") {
    drawEnd("Game Over", "Próbáld újra, és gyűjts még több tárgyat!");
    return;
  }

  drawBackground();

  for (const o of state.obstacles) {
    drawCar(o.x, o.y, o.color, false);
  }

  for (const it of state.items) {
    ctx.save();
    ctx.shadowColor = "rgba(255,215,0,.45)";
    ctx.shadowBlur = 8;
    ctx.font = ITEM_SIZE + "px serif";
    ctx.fillText(it.emoji, it.x - ITEM_SIZE/2, it.y + ITEM_SIZE/2);
    ctx.restore();
  }

  if (!(state.flashTimer > 0 && Math.floor(state.flashTimer / 5) % 2 === 0)) {
    drawCar(state.playerX + CAR_W/2, state.playerY + CAR_H/2, PLAYER_COLOR, true);
  }

  drawHUD();
}

function loop(){
  update();
  render();
  requestAnimationFrame(loop);
}

resetGame();
loop();
