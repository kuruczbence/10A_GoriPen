GoriPen – standalone verzió

Ez a csomag a feltöltött Lovable-export alapján készült, de úgy lett átalakítva,
hogy Lovable és fejlesztői szerver nélkül is megnyitható legyen.

Indítás:
- Nyisd meg közvetlenül az index.html fájlt böngészőben.

Mit tartalmaz:
- index.html
- styles.css
- game.js
- assets/ képek
- original_export/ az eredeti, feltöltött Lovable-export
