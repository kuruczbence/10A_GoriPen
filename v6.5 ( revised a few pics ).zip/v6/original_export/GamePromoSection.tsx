import gorillaMascot from "@/assets/gorilla-mascot.png";

const GamePromoSection = () => {
  return (
    <section className="py-14 bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center gap-8">
        <div className="flex-1 text-center md:text-left">
          <h2 className="text-3xl md:text-4xl font-display mb-3">🎮 Goripen Road Rush</h2>
          <p className="text-base opacity-90 max-w-lg mb-5">
            Play our mini-game! Dodge traffic, collect stationery items, and earn exclusive reward coupons
            for the shop. Use W/A/D to drive — how far can you go?
          </p>
          <a
            href="#game"
            className="inline-block bg-secondary text-secondary-foreground px-8 py-3 rounded-xl font-bold text-base hover:opacity-90 transition-opacity"
          >
            Play Now ▼
          </a>
        </div>
        <img
          src={gorillaMascot}
          alt="GoriPen mascot"
          className="w-32 md:w-44 drop-shadow-lg opacity-90"
          loading="lazy"
          width={512}
          height={512}
        />
      </div>
    </section>
  );
};

export default GamePromoSection;
