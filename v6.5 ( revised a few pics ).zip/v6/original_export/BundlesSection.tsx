import productBundle from "@/assets/product-bundle.jpg";
import productGelPens from "@/assets/product-gel-pens.jpg";
import productNotebook from "@/assets/product-notebook.jpg";

const bundles = [
  {
    name: "Back to School Kit",
    items: "Gel pens + Notebook + Stickers + Pencil case",
    originalPrice: "€18.46",
    price: "€13.99",
    image: productBundle,
  },
  {
    name: "Creative Starter Pack",
    items: "Markers + Notebook + Planner",
    originalPrice: "€16.97",
    price: "€11.99",
    image: productGelPens,
  },
  {
    name: "Study Essentials",
    items: "2× Notebooks + Gel pens + Desk organizer",
    originalPrice: "€21.96",
    price: "€15.99",
    image: productNotebook,
  },
];

const BundlesSection = () => {
  return (
    <section id="bundles" className="py-14 bg-muted/40">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-display text-center text-foreground mb-2">Featured Bundles</h2>
        <p className="text-center text-muted-foreground text-sm mb-8">Save more when you bundle up!</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-4xl mx-auto">
          {bundles.map((b) => (
            <div key={b.name} className="bg-card rounded-2xl border overflow-hidden hover:shadow-lg transition-shadow group cursor-pointer">
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={b.image}
                  alt={b.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                  width={512}
                  height={512}
                />
              </div>
              <div className="p-4">
                <h3 className="font-display text-lg text-foreground">{b.name}</h3>
                <p className="text-muted-foreground text-xs mt-1">{b.items}</p>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-primary font-display text-xl">{b.price}</span>
                  <span className="text-muted-foreground text-sm line-through">{b.originalPrice}</span>
                </div>
                <button className="w-full mt-3 bg-secondary text-secondary-foreground py-2 rounded-lg text-sm font-bold hover:opacity-90 transition-opacity">
                  Get Bundle
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BundlesSection;
