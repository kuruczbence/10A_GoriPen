import { useState } from "react";
import gorillaMascot from "@/assets/gorilla-mascot.png";

const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-card/90 backdrop-blur-md border-b">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <a href="#" className="flex items-center gap-2">
          <img src={gorillaMascot} alt="GoriPen mascot" className="w-10 h-10 object-contain" />
          <span className="font-display text-2xl text-primary">GoriPen</span>
        </a>

        <div className="hidden md:flex items-center gap-6 font-body font-semibold text-sm">
          <a href="#products" className="text-foreground/70 hover:text-primary transition-colors">Products</a>
          <a href="#bundles" className="text-foreground/70 hover:text-primary transition-colors">Bundles</a>
          <a href="#about" className="text-foreground/70 hover:text-primary transition-colors">About</a>
          <a href="#game" className="text-foreground/70 hover:text-primary transition-colors">Play Game</a>
          <a href="#rewards" className="text-foreground/70 hover:text-primary transition-colors">Rewards</a>
        </div>

        <div className="flex items-center gap-3">
          <button className="bg-primary text-primary-foreground px-4 py-2 rounded-lg font-semibold text-sm hover:opacity-90 transition-opacity">
            🛒 Cart (0)
          </button>
          <button
            className="md:hidden text-foreground p-1"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {mobileOpen ? (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              ) : (
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="md:hidden bg-card border-t px-4 py-3 flex flex-col gap-3 font-body font-semibold text-sm">
          <a href="#products" className="text-foreground/70 hover:text-primary" onClick={() => setMobileOpen(false)}>Products</a>
          <a href="#bundles" className="text-foreground/70 hover:text-primary" onClick={() => setMobileOpen(false)}>Bundles</a>
          <a href="#about" className="text-foreground/70 hover:text-primary" onClick={() => setMobileOpen(false)}>About</a>
          <a href="#game" className="text-foreground/70 hover:text-primary" onClick={() => setMobileOpen(false)}>Play Game</a>
          <a href="#rewards" className="text-foreground/70 hover:text-primary" onClick={() => setMobileOpen(false)}>Rewards</a>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
