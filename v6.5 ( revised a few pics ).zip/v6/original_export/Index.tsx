import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import CategoriesSection from "@/components/CategoriesSection";
import ProductsSection from "@/components/ProductsSection";
import BundlesSection from "@/components/BundlesSection";
import GamePromoSection from "@/components/GamePromoSection";
import RoadRushGame from "@/components/RoadRushGame";
import RewardsSection from "@/components/RewardsSection";
import AboutSection from "@/components/AboutSection";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <CategoriesSection />
      <ProductsSection />
      <BundlesSection />
      <GamePromoSection />
      <RoadRushGame />
      <RewardsSection />
      <AboutSection />
      <Footer />
    </div>
  );
};

export default Index;
