const rewards = [
  { items: 10, reward: "5% off", code: "GORI5", emoji: "🥉" },
  { items: 25, reward: "10% off", code: "GORI10", emoji: "🥈" },
  { items: 50, reward: "20% off", code: "GORI20", emoji: "🥇" },
];

const RewardsSection = () => {
  return (
    <section id="rewards" className="py-14">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-2xl md:text-3xl font-display text-foreground mb-2">🎁 Rewards & Coupons</h2>
        <p className="text-muted-foreground max-w-lg mx-auto mb-8 text-sm">
          Collect stationery in Road Rush to unlock exclusive shop discounts!
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-3xl mx-auto">
          {rewards.map((r) => (
            <div key={r.code} className="bg-card border rounded-2xl p-6 hover:shadow-md transition-shadow">
              <div className="text-4xl mb-2">{r.emoji}</div>
              <p className="font-bold text-foreground mb-1">Collect {r.items} items</p>
              <p className="text-primary font-display text-xl mb-2">{r.reward}</p>
              <code className="bg-muted px-3 py-1 rounded text-sm font-bold text-muted-foreground">{r.code}</code>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RewardsSection;
