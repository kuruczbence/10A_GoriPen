import gorillaMascot from "@/assets/gorilla-mascot.png";
import heroBg from "@/assets/hero-bg.jpg";

const HeroSection = () => {
  return (
    <section className="relative overflow-hidden min-h-[520px] flex items-center">
      <div className="absolute inset-0">
        <img src={heroBg} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-card/95 via-card/80 to-card/40" />
      </div>
      <div className="container mx-auto px-4 relative z-10 flex flex-col md:flex-row items-center gap-8 py-16">
        <div className="flex-1 text-center md:text-left">
          <p className="text-primary font-bold text-sm uppercase tracking-wider mb-2">Welcome to GoriPen</p>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-display text-foreground leading-tight mb-4">
            Gear Up for <span className="text-primary">School</span> in Style!
          </h1>
          <p className="text-lg text-muted-foreground mb-8 max-w-lg">
            The coolest stationery, notebooks, and school supplies — picked by our gorilla himself. Get creative with GoriPen!
          </p>
          <div className="flex gap-4 justify-center md:justify-start">
            <a href="#products" className="bg-primary text-primary-foreground px-7 py-3 rounded-xl font-bold text-base hover:opacity-90 transition-opacity shadow-md">
              Shop Now
            </a>
            <a href="#game" className="bg-secondary text-secondary-foreground px-7 py-3 rounded-xl font-bold text-base hover:opacity-90 transition-opacity shadow-md">
              🎮 Play & Win
            </a>
          </div>
        </div>
        <div className="flex-shrink-0">
          <img
            src={gorillaMascot}
            alt="GoriPen gorilla mascot"
            className="w-48 md:w-64 animate-float drop-shadow-2xl"
            width={512}
            height={512}
          />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
