import { useRef, useEffect, useState, useCallback } from "react";

const CANVAS_W = 420;
const CANVAS_H = 620;
const ROAD_LEFT = 65;
const ROAD_RIGHT = CANVAS_W - 65;
const ROAD_W = ROAD_RIGHT - ROAD_LEFT;
const LANE_COUNT = 4;
const LANE_W = ROAD_W / LANE_COUNT;
const CAR_W = 38;
const CAR_H = 60;
const ITEM_SIZE = 26;
const OBS_SPEED_BASE = 2.2;
const ITEM_SPEED_BASE = 1.8;
const PLAYER_SPEED_X = 3.5;
const PLAYER_SPEED_Y = 2.8;
const PLAYER_ACCEL = 0.4;
const PLAYER_FRICTION = 0.88;
const SPAWN_INTERVAL = 65;
const ITEM_INTERVAL = 48;
const MILESTONE_ITEMS = [10, 25, 50];

const STATIONERY_ITEMS = [
  { emoji: "🖊️", name: "pen" },
  { emoji: "📓", name: "notebook" },
  { emoji: "⭐", name: "sticker" },
  { emoji: "🖍️", name: "marker" },
  { emoji: "📎", name: "clip" },
  { emoji: "✏️", name: "pencil" },
  { emoji: "📏", name: "ruler" },
];
const CAR_COLORS = ["#e74c3c", "#3498db", "#e67e22", "#9b59b6", "#1abc9c", "#f39c12"];
const GRASS_COLOR = "#7ec850";
const ROAD_COLOR = "#4a4a4a";
const SHOULDER_COLOR = "#666";
const PLAYER_COLOR = "hsl(158, 55%, 42%)";
const PLAYER_ROOF = "hsl(158, 55%, 55%)";

interface Obstacle {
  x: number; y: number; color: string; w: number; h: number; lane: number;
}
interface CollectItem {
  x: number; y: number; emoji: string;
}

const RoadRushGame = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<"menu" | "playing" | "over">("menu");
  const [finalScore, setFinalScore] = useState(0);
  const [unlockedCoupon, setUnlockedCoupon] = useState<string | null>(null);

  const gameRef = useRef({
    playerX: CANVAS_W / 2 - CAR_W / 2,
    playerY: CANVAS_H - CAR_H - 40,
    velX: 0,
    velY: 0,
    lives: 3,
    score: 0,
    collected: 0,
    obstacles: [] as Obstacle[],
    items: [] as CollectItem[],
    keys: {} as Record<string, boolean>,
    frame: 0,
    roadOffset: 0,
    animId: 0,
    milestone: 0,
    flashTimer: 0,
    invincible: 0,
  });

  const startGame = useCallback(() => {
    const g = gameRef.current;
    g.playerX = CANVAS_W / 2 - CAR_W / 2;
    g.playerY = CANVAS_H - CAR_H - 40;
    g.velX = 0;
    g.velY = 0;
    g.lives = 3;
    g.score = 0;
    g.collected = 0;
    g.obstacles = [];
    g.items = [];
    g.frame = 0;
    g.roadOffset = 0;
    g.milestone = 0;
    g.flashTimer = 0;
    g.invincible = 0;
    setUnlockedCoupon(null);
    setGameState("playing");
  }, []);

  useEffect(() => {
    if (gameState !== "playing") return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    const g = gameRef.current;

    const onKey = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright"].includes(key)) {
        e.preventDefault();
      }
      g.keys[key] = e.type === "keydown";
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("keyup", onKey);

    const loop = () => {
      g.frame++;
      const speed = OBS_SPEED_BASE + g.score * 0.004;

      // Player movement with momentum
      if (g.keys["a"] || g.keys["arrowleft"]) g.velX -= PLAYER_ACCEL;
      if (g.keys["d"] || g.keys["arrowright"]) g.velX += PLAYER_ACCEL;
      if (g.keys["w"] || g.keys["arrowup"]) g.velY -= PLAYER_ACCEL;
      if (g.keys["s"] || g.keys["arrowdown"]) g.velY += PLAYER_ACCEL * 0.5;

      g.velX *= PLAYER_FRICTION;
      g.velY *= PLAYER_FRICTION;

      g.velX = Math.max(-PLAYER_SPEED_X, Math.min(PLAYER_SPEED_X, g.velX));
      g.velY = Math.max(-PLAYER_SPEED_Y, Math.min(PLAYER_SPEED_Y, g.velY));

      g.playerX += g.velX;
      g.playerY += g.velY;

      g.playerX = Math.max(ROAD_LEFT + 6, Math.min(ROAD_RIGHT - CAR_W - 6, g.playerX));
      g.playerY = Math.max(70, Math.min(CANVAS_H - CAR_H - 12, g.playerY));

      g.roadOffset = (g.roadOffset + speed) % 40;

      if (g.invincible > 0) g.invincible--;
      if (g.flashTimer > 0) g.flashTimer--;

      // Spawn obstacles
      if (g.frame % Math.max(28, SPAWN_INTERVAL - Math.floor(g.score / 4)) === 0) {
        const lane = Math.floor(Math.random() * LANE_COUNT);
        g.obstacles.push({
          x: ROAD_LEFT + lane * LANE_W + (LANE_W - CAR_W) / 2,
          y: -CAR_H - 10,
          color: CAR_COLORS[Math.floor(Math.random() * CAR_COLORS.length)],
          w: CAR_W, h: CAR_H, lane,
        });
      }

      // Spawn items
      if (g.frame % ITEM_INTERVAL === 0) {
        const item = STATIONERY_ITEMS[Math.floor(Math.random() * STATIONERY_ITEMS.length)];
        g.items.push({
          x: ROAD_LEFT + 18 + Math.random() * (ROAD_W - 36),
          y: -ITEM_SIZE,
          emoji: item.emoji,
        });
      }

      g.obstacles.forEach((o) => (o.y += speed));
      g.obstacles = g.obstacles.filter((o) => o.y < CANVAS_H + 20);

      g.items.forEach((i) => (i.y += ITEM_SPEED_BASE + speed * 0.3));
      g.items = g.items.filter((i) => i.y < CANVAS_H + 20);

      // Collisions
      if (g.invincible <= 0) {
        for (const o of g.obstacles) {
          if (
            g.playerX < o.x + o.w - 8 &&
            g.playerX + CAR_W > o.x + 8 &&
            g.playerY < o.y + o.h - 8 &&
            g.playerY + CAR_H > o.y + 8
          ) {
            g.lives--;
            g.invincible = 90;
            g.flashTimer = 30;
            o.y = CANVAS_H + 100;
            if (g.lives <= 0) {
              setFinalScore(g.score);
              setGameState("over");
              return;
            }
          }
        }
      }

      // Collect items
      for (let i = g.items.length - 1; i >= 0; i--) {
        const it = g.items[i];
        const cx = g.playerX + CAR_W / 2;
        const cy = g.playerY + CAR_H / 2;
        if (Math.abs(cx - it.x) < 26 && Math.abs(cy - it.y) < 26) {
          g.items.splice(i, 1);
          g.score += 1;
          g.collected += 1;
          for (let m = MILESTONE_ITEMS.length - 1; m >= 0; m--) {
            if (g.collected >= MILESTONE_ITEMS[m] && g.milestone <= m) {
              g.milestone = m + 1;
              const codes = ["GORI5", "GORI10", "GORI20"];
              setUnlockedCoupon(codes[m]);
              g.flashTimer = 60;
            }
          }
        }
      }

      // === DRAW ===
      // Grass
      ctx.fillStyle = GRASS_COLOR;
      ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

      // Grass details
      for (let fy = 0; fy < CANVAS_H; fy += 45) {
        for (const fx of [12, 38, CANVAS_W - 38, CANVAS_W - 12]) {
          const offset = ((fy + g.roadOffset * 2) % 90) - 5;
          ctx.font = "9px serif";
          ctx.fillText("🌼", fx + (fy % 18) - 4, fy + offset);
        }
      }

      // Road shoulder
      ctx.fillStyle = SHOULDER_COLOR;
      ctx.fillRect(ROAD_LEFT - 4, 0, ROAD_W + 8, CANVAS_H);

      // Road surface
      ctx.fillStyle = ROAD_COLOR;
      ctx.fillRect(ROAD_LEFT, 0, ROAD_W, CANVAS_H);

      // Road edges
      ctx.fillStyle = "#eee";
      ctx.fillRect(ROAD_LEFT, 0, 3, CANVAS_H);
      ctx.fillRect(ROAD_RIGHT - 3, 0, 3, CANVAS_H);

      // Lane dashes
      ctx.strokeStyle = "#aaa";
      ctx.lineWidth = 2;
      ctx.setLineDash([18, 18]);
      for (let l = 1; l < LANE_COUNT; l++) {
        const lx = ROAD_LEFT + l * LANE_W;
        ctx.beginPath();
        for (let dy = -g.roadOffset; dy < CANVAS_H + 40; dy += 36) {
          ctx.moveTo(lx, dy);
          ctx.lineTo(lx, dy + 18);
        }
        ctx.stroke();
      }
      ctx.setLineDash([]);

      // Draw obstacles
      for (const o of g.obstacles) {
        drawCar(ctx, o.x, o.y, o.color, false);
      }

      // Draw items with glow
      for (const it of g.items) {
        ctx.save();
        ctx.shadowColor = "rgba(255,215,0,0.5)";
        ctx.shadowBlur = 8;
        ctx.font = `${ITEM_SIZE}px serif`;
        ctx.fillText(it.emoji, it.x - ITEM_SIZE / 2, it.y + ITEM_SIZE / 2);
        ctx.restore();
      }

      // Draw player car (blink when invincible)
      if (g.invincible <= 0 || g.frame % 6 < 4) {
        drawPlayerCar(ctx, g.playerX, g.playerY);
      }

      // HUD background
      const hudH = 38;
      ctx.fillStyle = "rgba(0,0,0,0.65)";
      roundRect(ctx, 0, 0, CANVAS_W, hudH, 0);
      ctx.fill();

      ctx.fillStyle = "#fff";
      ctx.font = "bold 14px Nunito, sans-serif";
      ctx.textBaseline = "middle";

      // Lives
      for (let l = 0; l < g.lives; l++) {
        ctx.fillText("❤️", 12 + l * 22, hudH / 2);
      }

      // Score
      ctx.fillText(`⭐ ${g.score}`, 90, hudH / 2);

      if (unlockedCoupon) {
        ctx.fillStyle = "#ffd700";
        ctx.fillText(`🎟️ ${unlockedCoupon}`, 160, hudH / 2);
      }

      ctx.textBaseline = "alphabetic";

      // Milestone flash
      if (g.flashTimer > 0 && g.flashTimer % 10 < 5) {
        ctx.fillStyle = "rgba(255,215,0,0.12)";
        ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
      }

      g.animId = requestAnimationFrame(loop);
    };

    g.animId = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(g.animId);
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("keyup", onKey);
    };
  }, [gameState, unlockedCoupon]);

  return (
    <section id="game" className="py-14 bg-muted/40">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-2xl md:text-3xl font-display text-foreground mb-2">🎮 Goripen Road Rush</h2>
        <p className="text-muted-foreground mb-5 text-sm">
          Use <kbd className="bg-card border px-1.5 py-0.5 rounded font-bold text-xs">W</kbd>{" "}
          <kbd className="bg-card border px-1.5 py-0.5 rounded font-bold text-xs">A</kbd>{" "}
          <kbd className="bg-card border px-1.5 py-0.5 rounded font-bold text-xs">S</kbd>{" "}
          <kbd className="bg-card border px-1.5 py-0.5 rounded font-bold text-xs">D</kbd>{" "}
          to drive. Collect items, dodge cars, earn coupons!
        </p>

        <div className="inline-block relative rounded-2xl overflow-hidden border-4 border-primary shadow-xl">
          <canvas
            ref={canvasRef}
            width={CANVAS_W}
            height={CANVAS_H}
            className="block"
            style={{ background: GRASS_COLOR }}
            tabIndex={0}
          />

          {gameState === "menu" && (
            <div className="absolute inset-0 bg-brand-dark/85 flex flex-col items-center justify-center gap-4 p-6">
              <div className="text-5xl">🦍</div>
              <h3 className="font-display text-2xl text-primary-foreground">Road Rush</h3>
              <p className="text-primary-foreground/70 text-sm max-w-xs">
                Dodge traffic & collect stationery to earn reward coupons for the shop!
              </p>
              <button
                onClick={startGame}
                className="bg-primary text-primary-foreground px-8 py-3 rounded-xl font-bold text-lg hover:opacity-90 transition-opacity animate-pulse-glow"
              >
                Start Game
              </button>
            </div>
          )}

          {gameState === "over" && (
            <div className="absolute inset-0 bg-brand-dark/85 flex flex-col items-center justify-center gap-3 p-6">
              <div className="text-4xl">💥</div>
              <h3 className="font-display text-2xl text-primary-foreground">Game Over!</h3>
              <p className="text-primary-foreground/70">
                You collected <span className="font-bold text-secondary">{finalScore}</span> items
              </p>
              {unlockedCoupon && (
                <div className="bg-primary/20 rounded-xl px-4 py-2">
                  <p className="text-primary-foreground font-bold text-sm">
                    🎟️ Coupon unlocked: <span className="text-secondary">{unlockedCoupon}</span>
                  </p>
                </div>
              )}
              <button
                onClick={startGame}
                className="bg-primary text-primary-foreground px-8 py-3 rounded-xl font-bold hover:opacity-90 transition-opacity mt-2"
              >
                Play Again
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

function drawCar(ctx: CanvasRenderingContext2D, x: number, y: number, color: string, _isPlayer: boolean) {
  // Shadow
  ctx.fillStyle = "rgba(0,0,0,0.15)";
  roundRect(ctx, x + 3, y + 10, CAR_W - 2, CAR_H - 8, 8);
  ctx.fill();
  // Body
  ctx.fillStyle = color;
  roundRect(ctx, x + 2, y + 6, CAR_W - 4, CAR_H - 8, 8);
  ctx.fill();
  // Roof
  ctx.fillStyle = lighten(color, 25);
  roundRect(ctx, x + 7, y + 16, CAR_W - 14, CAR_H - 32, 5);
  ctx.fill();
  // Windshield
  ctx.fillStyle = "rgba(180,220,255,0.6)";
  roundRect(ctx, x + 8, y + CAR_H - 22, CAR_W - 16, 8, 3);
  ctx.fill();
  // Wheels
  ctx.fillStyle = "#222";
  roundRect(ctx, x - 2, y + 10, 5, 12, 2); ctx.fill();
  roundRect(ctx, x + CAR_W - 3, y + 10, 5, 12, 2); ctx.fill();
  roundRect(ctx, x - 2, y + CAR_H - 20, 5, 12, 2); ctx.fill();
  roundRect(ctx, x + CAR_W - 3, y + CAR_H - 20, 5, 12, 2); ctx.fill();
  // Tail lights
  ctx.fillStyle = "#e74c3c";
  ctx.fillRect(x + 6, y + CAR_H - 5, 5, 3);
  ctx.fillRect(x + CAR_W - 11, y + CAR_H - 5, 5, 3);
}

function drawPlayerCar(ctx: CanvasRenderingContext2D, x: number, y: number) {
  // Shadow
  ctx.fillStyle = "rgba(0,0,0,0.18)";
  roundRect(ctx, x + 3, y + 10, CAR_W - 2, CAR_H - 8, 8);
  ctx.fill();
  // Body
  ctx.fillStyle = PLAYER_COLOR;
  roundRect(ctx, x + 2, y + 6, CAR_W - 4, CAR_H - 8, 8);
  ctx.fill();
  // Roof
  ctx.fillStyle = PLAYER_ROOF;
  roundRect(ctx, x + 7, y + 16, CAR_W - 14, CAR_H - 32, 5);
  ctx.fill();
  // Gorilla driver
  ctx.font = "14px serif";
  ctx.fillText("🦍", x + CAR_W / 2 - 7, y + 32);
  // Windshield
  ctx.fillStyle = "rgba(180,220,255,0.5)";
  roundRect(ctx, x + 8, y + 6, CAR_W - 16, 8, 3);
  ctx.fill();
  // Wheels
  ctx.fillStyle = "#222";
  roundRect(ctx, x - 2, y + 10, 5, 12, 2); ctx.fill();
  roundRect(ctx, x + CAR_W - 3, y + 10, 5, 12, 2); ctx.fill();
  roundRect(ctx, x - 2, y + CAR_H - 20, 5, 12, 2); ctx.fill();
  roundRect(ctx, x + CAR_W - 3, y + CAR_H - 20, 5, 12, 2); ctx.fill();
  // Headlights
  ctx.fillStyle = "#ffd700";
  ctx.fillRect(x + 6, y + 2, 5, 4);
  ctx.fillRect(x + CAR_W - 11, y + 2, 5, 4);
  // Brand stripe
  ctx.fillStyle = "hsl(40, 95%, 60%)";
  ctx.fillRect(x + 4, y + CAR_H / 2 - 1, CAR_W - 8, 2);
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function lighten(hex: string, pct: number) {
  const num = parseInt(hex.replace("#", ""), 16);
  const r = Math.min(255, ((num >> 16) & 255) + pct);
  const g = Math.min(255, ((num >> 8) & 255) + pct);
  const b = Math.min(255, (num & 255) + pct);
  return `rgb(${r},${g},${b})`;
}

export default RoadRushGame;
