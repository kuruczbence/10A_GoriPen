import gorillaMascot from "@/assets/gorilla-mascot.png";

const Footer = () => {
  return (
    <footer className="bg-foreground text-background/70 py-10">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-3 text-center md:text-left">
            <img src={gorillaMascot} alt="GoriPen" className="w-8 h-8 object-contain opacity-80" loading="lazy" width={64} height={64} />
            <div>
              <span className="font-display text-xl text-background">GoriPen</span>
              <p className="text-xs mt-0.5 opacity-70">The coolest stationery shop on the web 🦍</p>
            </div>
          </div>
          <div className="flex gap-6 text-sm">
            <a href="#products" className="hover:text-background transition-colors">Products</a>
            <a href="#bundles" className="hover:text-background transition-colors">Bundles</a>
            <a href="#about" className="hover:text-background transition-colors">About</a>
            <a href="#game" className="hover:text-background transition-colors">Game</a>
            <a href="#rewards" className="hover:text-background transition-colors">Rewards</a>
          </div>
          <p className="text-xs opacity-60">© 2026 GoriPen — School Project. Not a real store.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
