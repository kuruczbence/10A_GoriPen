import productGelPens from "@/assets/product-gel-pens.jpg";
import productNotebook from "@/assets/product-notebook.jpg";
import productStickers from "@/assets/product-stickers.jpg";
import productPencilCase from "@/assets/product-pencil-case.jpg";
import productMarkers from "@/assets/product-markers.jpg";
import productPlanner from "@/assets/product-planner.jpg";
import productDeskOrganizer from "@/assets/product-desk-organizer.jpg";
import productBundle from "@/assets/product-bundle.jpg";

const products = [
  { name: "Gel Pen Set (8 pcs)", price: "€4.99", badge: "Best Seller", image: productGelPens, desc: "Smooth ink, vibrant colors" },
  { name: "Jungle Notebook A5", price: "€3.49", badge: null, image: productNotebook, desc: "120 lined pages, spiral bound" },
  { name: "Holographic Sticker Pack", price: "€2.99", badge: "New", image: productStickers, desc: "30+ fun school stickers" },
  { name: "Gorilla Pencil Case", price: "€6.99", badge: null, image: productPencilCase, desc: "Spacious zipper pouch" },
  { name: "Neon Marker Set (12 pcs)", price: "€7.49", badge: null, image: productMarkers, desc: "Dual-tip, water-based" },
  { name: "Weekly Planner — Pastel", price: "€5.99", badge: "Popular", image: productPlanner, desc: "52 weeks, tab dividers" },
  { name: "Desk Organizer — Teal", price: "€9.99", badge: null, image: productDeskOrganizer, desc: "4 compartments, sturdy" },
  { name: "School Starter Bundle", price: "€14.99", badge: "Value Pack", image: productBundle, desc: "Everything to start the year" },
];

const ProductsSection = () => {
  return (
    <section id="products" className="py-14">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-display text-center text-foreground mb-2">Featured Products</h2>
        <p className="text-center text-muted-foreground text-sm mb-8">Hand-picked by our gorilla for every student</p>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-5">
          {products.map((p) => (
            <div key={p.name} className="bg-card rounded-2xl border p-3 md:p-4 hover:shadow-lg transition-shadow group cursor-pointer">
              <div className="bg-muted rounded-xl overflow-hidden mb-3 aspect-square">
                <img
                  src={p.image}
                  alt={p.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                  width={512}
                  height={512}
                />
              </div>
              <div className="flex items-start justify-between gap-1">
                <div className="min-w-0">
                  <h3 className="font-bold text-sm text-foreground leading-tight truncate">{p.name}</h3>
                  <p className="text-muted-foreground text-xs mt-0.5">{p.desc}</p>
                  <p className="text-primary font-display text-lg mt-1">{p.price}</p>
                </div>
                {p.badge && (
                  <span className="bg-accent text-accent-foreground text-[10px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap flex-shrink-0">
                    {p.badge}
                  </span>
                )}
              </div>
              <button className="w-full mt-3 bg-primary text-primary-foreground py-2 rounded-lg text-sm font-bold hover:opacity-90 transition-opacity">
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductsSection;
