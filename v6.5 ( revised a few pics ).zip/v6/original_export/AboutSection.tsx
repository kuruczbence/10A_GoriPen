import gorillaMascot from "@/assets/gorilla-mascot.png";

const AboutSection = () => {
  return (
    <section id="about" className="py-14">
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center gap-10">
        <img src={gorillaMascot} alt="GoriPen mascot" className="w-36 md:w-48 drop-shadow-lg" loading="lazy" width={512} height={512} />
        <div className="max-w-xl text-center md:text-left">
          <h2 className="text-2xl md:text-3xl font-display text-foreground mb-4">Meet GoriPen 🦍</h2>
          <p className="text-muted-foreground leading-relaxed mb-3">
            GoriPen is a fictional stationery brand founded by the coolest gorilla in town.
            Our mission? Making school supplies fun, affordable, and stylish for every student.
            From pens to planners, every product is designed to spark creativity.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            This project was built as a school assignment to demonstrate a working webshop concept
            with interactive elements. Everything you see — from the shop to the mini-game — is
            part of our presentation. 🎓
          </p>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
