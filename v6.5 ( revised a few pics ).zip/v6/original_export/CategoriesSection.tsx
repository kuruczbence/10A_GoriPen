const categories = [
  { name: "Pens & Gel Pens", emoji: "🖊️", bg: "bg-primary/10", text: "text-primary" },
  { name: "Notebooks", emoji: "📓", bg: "bg-secondary/20", text: "text-secondary-foreground" },
  { name: "Sticker Packs", emoji: "⭐", bg: "bg-accent/10", text: "text-accent" },
  { name: "Markers & Art", emoji: "🎨", bg: "bg-brand-sky/10", text: "text-brand-sky" },
  { name: "Pencil Cases", emoji: "🎒", bg: "bg-primary/10", text: "text-primary" },
  { name: "Planners", emoji: "📅", bg: "bg-secondary/20", text: "text-secondary-foreground" },
];

const CategoriesSection = () => {
  return (
    <section className="py-14 bg-muted/40">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-display text-center text-foreground mb-8">Shop by Category</h2>
        <div className="grid grid-cols-3 md:grid-cols-6 gap-3 md:gap-4">
          {categories.map((cat) => (
            <div
              key={cat.name}
              className={`${cat.bg} ${cat.text} rounded-2xl p-5 text-center cursor-pointer hover:scale-105 transition-transform`}
            >
              <div className="text-3xl md:text-4xl mb-2">{cat.emoji}</div>
              <div className="font-bold text-xs md:text-sm">{cat.name}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoriesSection;
